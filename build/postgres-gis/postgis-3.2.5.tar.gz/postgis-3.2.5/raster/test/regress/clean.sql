SET client_min_messages TO warning;

-- remove raster_outdb_template table
DROP TABLE IF EXISTS raster_outdb_template;
