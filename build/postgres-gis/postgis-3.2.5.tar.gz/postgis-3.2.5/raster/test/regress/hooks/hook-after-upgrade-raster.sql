DROP TABLE upgrade_test_raster;
